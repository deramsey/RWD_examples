$( document ).ready( function() {
    
    let a = Math.floor(Math.random()*360).toString();

    $("body").css("background-color", "hsl(" + a + ", 75%, 50%)")

    $("#chColor").on("click", function(){

        let c = Math.floor(Math.random()*360).toString();

        $("body").css("background-color", "hsl(" + c + ", 75%, 50%)")


    });

});